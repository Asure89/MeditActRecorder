package com.example.liya.medicinecalendar;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;


public class SaveSensorService extends Service implements SensorEventListener {

    private static final String TAG = "SaveSensorService";

    private Float xValue, yValue, zValue, xGyroValue, yGyroValue, zGyroValue;
    SensorManager sensorManager;
    private Sensor accelerometer, mGyro;


    private SimpleDateFormat Date_Format,Newtime_Format;
    private  Calendar calendar;
    private String CurrentTime, FileName, StartTime,StopTime;

    File myFile;
    FileOutputStream fileOutputStream,fos;
    OutputStreamWriter myOutWriter;
    BufferedWriter myBufferedWriter;
    PrintWriter myPrintWriter;
    boolean startFlag = true;
/*
    final class MyThreadClass implements Runnable {
        int service_id;

        MyThreadClass(int service_id) {
            //initialize the variable
            this.service_id = service_id;
        }

        @Override
        public void run() {
            save(FileName);
        }

    }
*/
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: SaveSensorService started.");


        //set the sensor to capture the movement of the patient - accelerometer and  gyroscope
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(SaveSensorService.this, accelerometer,1000*1000*1000);
            Log.d(TAG, "onCreate: Registered accelerometer Listener");
        } /*else {
            xValue = null;
            yValue = null;
            zValue = null;

        }*/

        mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (mGyro != null) {
            sensorManager.registerListener(SaveSensorService.this, mGyro, 1000*1000*1000);
            Log.d(TAG, "onCreate: Registered Gyro Listener");

        } /*else {
            xGyroValue = null;
            yGyroValue = null;
            zGyroValue = null;
        }*/

        //if the device doesn't support the sensors, stop the service
        if (mGyro == null && accelerometer == null){
            stopSelf();
            Log.d(TAG, "onStartCommand: Device not support");
            Toast.makeText(SaveSensorService.this, "Device not support",Toast.LENGTH_SHORT).show();
        }
        else {
            Log.d(TAG, "onCreate:Sensor Services initialized.");
        }

        //declare file name
        Date_Format = new SimpleDateFormat("yyyyMMddHHmm");
        calendar = Calendar.getInstance();
        FileName = Date_Format.format(calendar.getTime()) + ".txt";
        Toast.makeText(SaveSensorService.this, FileName + " SaveSensorService is running", Toast.LENGTH_SHORT).show();

        //create new file
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(FileName, MODE_APPEND);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //write the first line - description
        try {
            fos.write("CurrentTime\txValue\tyValue\tzValue\txGyroValue\tyGyroValue\tzGyroValue\r\n".getBytes()); //define the first line
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
            Log.d(TAG,"Die Daten wurden unter "+getFilesDir()+FileName+"gespeichert.");
            Toast.makeText(this,"Daten werden unter "+getFilesDir()+FileName+"gespeichert.",Toast.LENGTH_SHORT).show();

            return START_STICKY;
    }

        @Override
         public void onDestroy() {
            sensorManager.unregisterListener(SaveSensorService.this);
            CurrentTime = Newtime_Format.format((Calendar.getInstance()).getTime());
            Log.d(TAG, "onDestroy: SaveSensorService stopped."+CurrentTime);
            Toast.makeText(SaveSensorService.this,"SaveSensorService beendet."+ CurrentTime,Toast.LENGTH_SHORT).show();
            }

    /******************************* set the data from sensors to variables - START ***************************/
    public void save(String FileName) throws IOException {
        fileOutputStream= openFileOutput(FileName, MODE_APPEND);
        myOutWriter = new OutputStreamWriter(fileOutputStream);
        myBufferedWriter = new BufferedWriter(myOutWriter);
        myPrintWriter = new PrintWriter(myBufferedWriter);

        //write the first line - description
        myPrintWriter.write(CurrentTime+"\t"+xValue+"\t"+yValue+"\t"+zValue+"\t"+xGyroValue+"\t"+yGyroValue+"\t"+zGyroValue+"\r\n"); //define the first line


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        //get sensor data

        if(sensor.getType()==Sensor.TYPE_ACCELEROMETER) {
            Log.d(TAG, "onSensorChanged: X:" + sensorEvent.values[0] + "\tY:" + sensorEvent.values[1] + "\tZ:" + sensorEvent.values[2]);


            xValue = sensorEvent.values[0];
            yValue = sensorEvent.values[1];
            zValue = sensorEvent.values[2];

        }


        //put gyrocope data on layout
        else if(sensor.getType()==Sensor.TYPE_GYROSCOPE) {
            Log.d(TAG, "onSensorChanged: XG:" + sensorEvent.values[0] + "\tYG:" + sensorEvent.values[1] + "\tZG:" + sensorEvent.values[2]);

            xGyroValue = sensorEvent.values[0];
            yGyroValue = sensorEvent.values[1];
            zGyroValue = sensorEvent.values[2];
        }
/*
        try {
            save(FileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
  */
    }

    /******************************* set the data from sensors to variables - END ***************************/

}
