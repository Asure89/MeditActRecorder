package com.example.liya.medicinecalendar;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SaveDataService extends Service {
/*here we build this service to keep saving sensor data in the background
after the every time the patient has confirmed that he/she already took the medicine*/

    private static final String TAG = "SaveDataService";

    private SensorManager sensorManager;

    SensorEventListener listen;

    private Sensor accelerometer, mGyro;

    private Calendar calendar;

    private SimpleDateFormat Newtime_Format;

    private Float xValue, yValue, zValue, xGyroValue, yGyroValue, zGyroValue;

    private String Starttime, Stoptime, Path, Date;

    @Nullable
    @Override
    //neccessary in a service
    public IBinder onBind(Intent intent)
    {
        Log.d(TAG, "onBind: succeed.");
        return null;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate: succeed.");
        Toast.makeText(getApplicationContext(),"Started",Toast.LENGTH_SHORT).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Date =(String) intent.getExtras().get("lastdate");
        Starttime = (String) intent.getExtras().get("lasttime");
        Path =(String) intent.getExtras().get("filepath");


        //implement the sensors
        listen = new SensorListen();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if(accelerometer != null){
            sensorManager.registerListener(listen, accelerometer,500000);
            Log.d(TAG, "onCreate: Registered accelerometer Listener");}
        else{
            Toast.makeText(SaveDataService.this,"The device doesn't support accelerometer.",Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onStartCommand: No accelerometer Listener");
        }
        mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        if(mGyro != null){
            sensorManager.registerListener(listen, mGyro, 500000);
            Log.d(TAG, "onCreate: Registered Gyro Listener");}
        else{
            Toast.makeText(SaveDataService.this,"The device doesn't support gyroscope.",Toast.LENGTH_SHORT).show();
            xGyroValue = null;
            yGyroValue = null;
            zGyroValue = null;
            Log.d(TAG, "onStartCommand: No Gyro Listener");
        }

        if(accelerometer == null && mGyro == null){
            Toast.makeText(SaveDataService.this,"The device doesn't support this service.",Toast.LENGTH_SHORT).show();
            stopSelf();
            Log.d(TAG, "onStartCommand: stop");
        }
        final String FILE_NAME = Date+Starttime;


        FileOutputStream fos = null;

        try {
            //to prevent that the file fail to be read or created, use catch to print the error
            /* write in txt*/
            fos = openFileOutput(FILE_NAME,MODE_APPEND);
            fos.write("xValue\tyValue\tzValue\txGyroValue\tyGyroValue\tzGyroValue\r\n".getBytes()); //define the first line

            Newtime_Format = new SimpleDateFormat("hhmm");
            calendar = Calendar.getInstance();
            calendar.add(Calendar.MINUTE, 30);
            Stoptime = Newtime_Format.format(calendar.getTime());

            while (Starttime.compareTo(Stoptime) < 0) {
                calendar = Calendar.getInstance();
                calendar.add(Calendar.MINUTE, 30);
                Stoptime = Newtime_Format.format(calendar.getTime());
                fos.write((xValue + "\t" + yValue + "\t" + zValue + "\t" + xGyroValue + "\t" + yGyroValue + "\t" + zGyroValue + "\r\n").getBytes());
            }
            Log.d(TAG, "onClick: file ist written.");
            Toast.makeText(SaveDataService.this,"succeed.",Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + FILE_NAME, Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Toast.makeText(SaveDataService.this,"Service started.",Toast.LENGTH_SHORT).show();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(SaveDataService.this,"Service stopped.",Toast.LENGTH_SHORT).show();
    }

    public class SensorListen implements SensorEventListener{

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        //get sensor data

        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            Log.d(TAG, "onSensorChanged: X:" + sensorEvent.values[0] + "Y:" + sensorEvent.values[1] + "Z:" + sensorEvent.values[2]);

            //put accelerometer data on layout
            xValue = sensorEvent.values[0];
            yValue = sensorEvent.values[1];
            zValue = sensorEvent.values[2];
        }

        //put gyrocope data on layout
        else if (sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            xGyroValue = sensorEvent.values[0];
            yGyroValue = sensorEvent.values[1];
            zGyroValue = sensorEvent.values[2];
        }
    }

    }

}