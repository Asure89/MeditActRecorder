package com.example.liya.medicinecalendar;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarActivity extends AppCompatActivity implements SensorEventListener {


    private static final String TAG = "CalendarActivity";

    private SensorManager sensorManager;

    private Sensor accelerometer, mGyro;

    Calendar calendar;

    SimpleDateFormat Newtime_Format;
    //String Date;
    //Button btnDateTime;

    TextView DateTimeView, xValueT, yValueT, zValueT, xGyroValueT, yGyroValueT, zGyroValueT;

    private Float xValue, yValue, zValue, xGyroValue, yGyroValue, zGyroValue;

    private String Stoptime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_layout);

        DateTimeView = (TextView) findViewById(R.id.DateTimeView);
        //btnDateTime = (Button) findViewById(R.id.btnDateTime);

        Intent incomingdata = getIntent();
        final String Date = incomingdata.getStringExtra("lastdate");
        final String Starttime = incomingdata.getStringExtra("lasttime");
        //final String Path = incomingdata.getStringExtra("filepath");
         final String FILE_NAME = Date+Starttime;

          DateTimeView.setText(Date);
                Log.d(TAG, "onSelectedDayChange: currenttime:" + Date);

                //receive instant time from MainActivity
                //File file = new File(Path+"/"+Date+Starttime+".txt");
                //Log.d(TAG, "onClick:the file"+file.getAbsolutePath()+ "is created" );
                //Toast.makeText(CalendarActivity.this,"the file"+Date+Starttime+"is created.",Toast.LENGTH_SHORT).show();

                    FileOutputStream fos = null;

                    try {
                        //to prevent that the file fail to be read or created, use catch to print the error
                        /* write in txt*/
                        fos = openFileOutput(FILE_NAME,MODE_APPEND);
                        fos.write("xValue\tyValue\tzValue\txGyroValue\tyGyroValue\tzGyroValue\r\n".getBytes()); //define the first line

                        Newtime_Format = new SimpleDateFormat("hhmm");
                        calendar = Calendar.getInstance();
                        calendar.add(Calendar.MINUTE, 30);
                        Stoptime = Newtime_Format.format(calendar.getTime());

                        while (Starttime.compareTo(Stoptime) < 0) {
                            calendar = Calendar.getInstance();
                            calendar.add(Calendar.MINUTE, 30);
                            Stoptime = Newtime_Format.format(calendar.getTime());
                            fos.write((xValue + "\t" + yValue + "\t" + zValue + "\t" + xGyroValue + "\t" + yGyroValue + "\t" + zGyroValue + "\r\n").getBytes());
                        }
                        Log.d(TAG, "onClick: file ist written.");
                        Toast.makeText(CalendarActivity.this,"succeed.",Toast.LENGTH_SHORT).show();
                        Toast.makeText(this, "Saved to " + getFilesDir() + "/" + FILE_NAME, Toast.LENGTH_SHORT).show();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        if (fos != null) {
                            try {
                                fos.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }


        xValueT = (TextView) findViewById(R.id.xValue);
        yValueT = (TextView) findViewById(R.id.yValue);
        zValueT = (TextView) findViewById(R.id.zValue);

        xGyroValueT = (TextView) findViewById(R.id.xGyroValue);
        yGyroValueT = (TextView) findViewById(R.id.yGyroValue);
        zGyroValueT = (TextView) findViewById(R.id.zGyroValue);
        Log.d(TAG, "onCreate: Initializing Sensor Services");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(accelerometer != null){
            sensorManager.registerListener(CalendarActivity.this, accelerometer, 5000000);
            Log.d(TAG, "onCreate: Registered accelerometer Listener");}
        else{
            xValueT.setText("Accelerometer not supported");
            yValueT.setText("Accelerometer not supported");
            zValueT.setText("Accelerometer not supported");
        }

        mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if(mGyro != null){
            sensorManager.registerListener(CalendarActivity.this, mGyro, 5000000);
            Log.d(TAG, "onCreate: Registered Gyro Listener");}
        else{
            xGyroValueT.setText("Gyroscope not supported");
            yGyroValueT.setText("Gyroscope not supported");
            zGyroValueT.setText("Gyroscope not supported");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        //get sensor data

        if(sensor.getType()==Sensor.TYPE_ACCELEROMETER) {
            Log.d(TAG, "onSensorChanged: X:" + sensorEvent.values[0] + "Y:" + sensorEvent.values[1] + "Z:" + sensorEvent.values[2]);

            //put accelerometer data on layout
            xValueT.setText("xValue:" + sensorEvent.values[0]);
            yValueT.setText("yValue:" + sensorEvent.values[1]);
            zValueT.setText("zValue:" + sensorEvent.values[2]);

            xValue = sensorEvent.values[0];
            yValue = sensorEvent.values[1];
            zValue = sensorEvent.values[2];


        }

        //put gyrocope data on layout
        else if(sensor.getType()==Sensor.TYPE_GYROSCOPE) {
            Log.d(TAG, "onSensorChanged: XG:" + sensorEvent.values[0] + "YG:" + sensorEvent.values[1] + "ZG:" + sensorEvent.values[2]);
            xGyroValueT.setText("xGValue:" + sensorEvent.values[0]);
            yGyroValueT.setText("yGValue:" + sensorEvent.values[1]);
            zGyroValueT.setText("zGValue:" + sensorEvent.values[2]);

            xGyroValue = sensorEvent.values[0];
            yGyroValue = sensorEvent.values[1];
            zGyroValue = sensorEvent.values[2];


        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();}
}
