package com.example.liya.medicinecalendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;


public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        //Create an intent to the alarmService
        Intent serviceIntent = new Intent(context,AlarmService.class);

        //start the intent
        context.startService(serviceIntent);
    }
}

