package com.example.liya.medicinecalendar;

import android.app.AlarmManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.security.Provider;

public class AlarmService extends Service{
    private MediaPlayer player;
    private Intent returnIntent;
    private static final String TAG = "AlarmService";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Toast.makeText(AlarmService.this, "AlarmService onBind.", Toast.LENGTH_SHORT).show();
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

       player = MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
        player.setLooping(true);
        player.start();
        Log.d(TAG, "onStartCommand: Alarm started.");
        Toast.makeText(AlarmService.this,"Alarm started.",Toast.LENGTH_SHORT).show();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
    Intent returnIntent = new Intent(AlarmService.this, MainActivity.class);
    player.stop();
    startActivity(returnIntent);
    Toast.makeText(AlarmService.this,"Alarm stopped.",Toast.LENGTH_SHORT).show();
}
}