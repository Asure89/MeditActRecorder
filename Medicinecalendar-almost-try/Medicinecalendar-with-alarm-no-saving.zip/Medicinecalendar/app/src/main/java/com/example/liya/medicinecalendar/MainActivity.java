package com.example.liya.medicinecalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import static java.util.Calendar.DAY_OF_MONTH;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    //to show layout
    private TextView Lasttime;
    private Button btnRecord;
    private TextView Nexttime;

    //to get time
    private Calendar calendar;
    private SimpleDateFormat Day_Format,DayT_Format, Time_Format, TimeT_Format;
    private String Day,DayT, Time,TimeT, NewTime;

    // to save intermediate data
    public static final String SHARED_PREFS = "sharedPrefs";

    //to update app view when restart the app
    private String ShowLASTTIME;
    private String ShowNEXTTIME;

    //to set the alarm
    AlarmManager alarmManager;
    Context context;
    PendingIntent pendingIntent;
    Intent my_intent;

    //define the saving path in the cellphone, so that we can find it later
    //public String path = Environment.getExternalStorageDirectory() + "/Medicine_Action_Tracking";

    @Override
    //first view of the app
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Lasttime = (TextView) findViewById(R.id.lasttime);
        btnRecord = (Button) findViewById(R.id.btnRecord);
        Nexttime = (TextView) findViewById(R.id.nexttime);
        this.context = this;

        //initialize the alarm manager
        final AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        //create a content to the alarm receiver
        final Intent my_intent = new Intent(this.context, AlarmReceiver.class);



        //share prefs data
        SharedPreferences sharedPreferences = getSharedPreferences("myTime",0);


        //create the fold Medicine_Action_Tracking
        /* externalStorage
        File dir = new File(path);
        dir.mkdirs();
        */

        //File time_file = new File(path, "everyTime.txt");
        //Log.d(TAG, "onCreate: new fold");

        //keep view
        loadData();
        updateViews();

        //define the action of the bottom
        btnRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopService(new Intent(MainActivity.this,AlarmService.class));
                //get current time
                calendar = Calendar.getInstance();
                Day_Format = new SimpleDateFormat("dd.MM.yyyy");
                DayT_Format = new SimpleDateFormat("yyyyMMdd");
                Time_Format = new SimpleDateFormat("HH:mm");
                TimeT_Format = new SimpleDateFormat("HHmm");
                Day = Day_Format.format(calendar.getTime());
                DayT = DayT_Format.format(calendar.getTime());
                Time = Time_Format.format(calendar.getTime());
                TimeT = TimeT_Format.format(calendar.getTime());

                //calendar.add(Calendar.HOUR_OF_DAY, 4);//for example: the medicine should be taken every 4 hours
                calendar.add(Calendar.SECOND, 10);
                Log.d(TAG, "onClick:" + calendar);
                //how to implement the new time?????? important!!!!
                //now the nexttime is saved in 'calendar'
                NewTime = TimeT_Format.format(calendar.getTime());
                //PendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, myIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                //show current time as this time of taking medicine and set the new time
                Lasttime.setText("Letzte Einnahme ist um " + Time + " am " + Day);
                if (NewTime.compareTo("2100")>0 || NewTime.compareTo("0700")<0) {
                    Nexttime.setText("Nächste Einnahme um 07:00" );
                    NewTime = "07:00";
                }

                else {
                    NewTime = Time_Format.format(calendar.getTime());
                    Nexttime.setText("Nächste Einnahme um " + NewTime);
                }

                PendingIntent pending_intent = PendingIntent.getBroadcast(MainActivity.this,0,my_intent,PendingIntent.FLAG_UPDATE_CURRENT);
                alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pending_intent);

                //switch to SaveDataService, deliver the time to the service as the name of the file
                //Intent intent = new Intent(MainActivity.this, SaveDataService.class);
                // intent.putExtra("lastdate",DayT);
                // intent.putExtra("lasttime",TimeT);
                // startService(intent);

                //switch to CalendarActivity
                /*Intent intent = new Intent(MainActivity.this, CalendarActivity.class);
                    intent.putExtra("lastdate",DayT);
                    intent.putExtra("lasttime",TimeT);
                    //intent.putExtra("filepath", path);

                //show that this confirm is recorded
                    Toast.makeText(MainActivity.this, "Diese Einnahme ist bestätigt.", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                  ;*/
                //Log.d(TAG, "onClick: jump to service");
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();

        //save it to sharePreference
        saveData();

    }

    public void saveData(){

        //save current input data to sharedpreference
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("MYLASTTIME", Lasttime.getText().toString());
        editor.putString("MYNEXTTIME", Nexttime.getText().toString());

        editor.apply();
        }

    //show the previous data when restarting the app
    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        ShowLASTTIME = sharedPreferences.getString("MYLASTTIME","");
        ShowNEXTTIME = sharedPreferences.getString("MYNEXTTIME","");
    }
    //update the initial view
    public void updateViews() {
        Lasttime.setText(ShowLASTTIME);
        Nexttime.setText(ShowNEXTTIME);
    }
}
