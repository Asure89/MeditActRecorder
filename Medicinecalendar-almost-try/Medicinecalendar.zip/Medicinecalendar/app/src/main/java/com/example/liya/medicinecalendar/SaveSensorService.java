package com.example.liya.medicinecalendar;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class SaveSensorService extends Service implements SensorEventListener {

    private static final String TAG = "SaveSensorService";

    private Float xValue, yValue, zValue, xGyroValue, yGyroValue, zGyroValue;
    SensorManager sensorManager;
    private Sensor accelerometer, mGyro;


    private SimpleDateFormat Date_Format,Newtime_Format;
    private  Calendar calendar;
    private String StartTime, StopTime, CurrentTime, FileName;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: SaveSensorService started.");

        Newtime_Format = new SimpleDateFormat("HHmmss");
        calendar = Calendar.getInstance();
        StartTime = Newtime_Format.format(calendar.getTime());
        CurrentTime = StartTime;
        //calendar.add(Calendar.MINUTE, 15);//save sensor data for 15min
        calendar.add(Calendar.SECOND,60);//for test
        StopTime = Newtime_Format.format(calendar.getTime());
        Toast.makeText(SaveSensorService.this, StartTime+" SaveSensorService is running",Toast.LENGTH_SHORT).show();


        Log.d(TAG, "onCreate: Initializing Sensor Services");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(SaveSensorService.this, accelerometer, 5000000);
            Log.d(TAG, "onCreate: Registered accelerometer Listener");
        } else {
            xValue = null;
            yValue = null;
            zValue = null;
            ;
        }

        mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (mGyro != null) {
            sensorManager.registerListener(SaveSensorService.this, mGyro, 5000000);
            Log.d(TAG, "onCreate: Registered Gyro Listener");
        } else {
            xGyroValue = null;
            yGyroValue = null;
            zGyroValue = null;
        }

        if ((accelerometer!=null || mGyro != null)&&CurrentTime.compareTo(StopTime) < 0) {
            calendar = Calendar.getInstance();
            CurrentTime = Newtime_Format.format(calendar.getTime());
            saveSensor();
        }

        else  {
            stopSelf();
            Toast.makeText(SaveSensorService.this,"Time's up or device not support."+ CurrentTime,Toast.LENGTH_SHORT).show();

        }

        return START_STICKY;
    }



    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy: SaveSensorService stopped.");
        Toast.makeText(SaveSensorService.this,"Sensordaten wurden gespeichert."+ CurrentTime,Toast.LENGTH_SHORT).show();
    }


    /******************************************* save the sensor data during the set time - START ************************************************************/

        public void saveSensor () {

            //create a new file, named by the current time
            Date_Format = new SimpleDateFormat("yyyyMMddHHmm");
            FileName = Date_Format.format(calendar.getTime())+".txt";

            try{
            FileOutputStream fos = null;


                //to prevent that the file fail to be read or created, use catch to print the error
                // write in txt,

                fos = openFileOutput(FileName, MODE_APPEND);
                //write the first line - description
                fos.write("xValue\tyValue\tzValue\txGyroValue\tyGyroValue\tzGyroValue\r\n".getBytes()); //define the first line

                    //append the sensor data in the file
                    fos.write((xValue + "\t" + yValue + "\t" + zValue + "\t" + xGyroValue + "\t" + yGyroValue + "\t" + zGyroValue + "\r\n").getBytes());
                    fos.flush();
                    fos.close();
                } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            Log.d(TAG, "onClick: file ist written.");
                Toast.makeText(this, "Saved to " + getFilesDir() + "/" + FileName, Toast.LENGTH_SHORT).show();

            }





    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        //get sensor data

        if(sensor.getType()==Sensor.TYPE_ACCELEROMETER) {
            Log.d(TAG, "onSensorChanged: X:" + sensorEvent.values[0] + "Y:" + sensorEvent.values[1] + "Z:" + sensorEvent.values[2]);

            xValue = sensorEvent.values[0];
            yValue = sensorEvent.values[1];
            zValue = sensorEvent.values[2];

        }

        //put gyrocope data on layout
        else if(sensor.getType()==Sensor.TYPE_GYROSCOPE) {
            Log.d(TAG, "onSensorChanged: XG:" + sensorEvent.values[0] + "YG:" + sensorEvent.values[1] + "ZG:" + sensorEvent.values[2]);

            xGyroValue = sensorEvent.values[0];
            yGyroValue = sensorEvent.values[1];
            zGyroValue = sensorEvent.values[2];

        }

    }

    /********************************************* save the sensor data during the set time - END ************************************************************/

}
